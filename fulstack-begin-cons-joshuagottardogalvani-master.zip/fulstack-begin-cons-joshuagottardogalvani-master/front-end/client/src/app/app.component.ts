import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  wall: string[];

  constructor(public http: HttpClient) {}

  ngOnInit(){
  }

  muri(){
    this.http.get('https://3000-ebc71c13-a800-4786-9e70-d416ef0f7b04.ws-eu01.gitpod.io/api/muro').subscribe(data => {
      this.wall = data['wall'];
      console.log(this.wall);
    });
  }
}
